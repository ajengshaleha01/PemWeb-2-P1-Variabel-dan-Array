<?php
    //mendeklarasikan variabel
    $nama = 'Ajeng';
    $umur = '19';
    $berat = '40';

    //menampilkan variabel
    echo 'Nama : '.$nama.'<br>';
    echo 'Umur : '.$umur.'<br>';
    echo 'Berat : '.$berat.'<br>';

    echo '<hr>';

    //menampilkan variabel tanpa penghubung
    echo "Nama : $nama<br>";
    echo "Umur : $umur<br>";
    echo "Berat : $berat<br>";
?>


<!----------------- Pertanyaan ---------------->
<!---- 
    1. Apa bedanya variabel user dengan variable system ?
    2. Apa persamaan variabel system dengan variabel konstan ?
--->

<!----------------- Jawaban ---------------->
<!----
    1. Perbedaan nya itu terletak di admin system, Variable system bisa digunakan secara global oleh semua pengguna dan variable user itu hanya bisa digunakan oleh pengguna yang mendeklarasikan variable itu.
    2. Variabel system adalah suatu tempat untuk menampung data yang nilainya selalu berubah. Sedangkan, Konstanta adalah suatu tempat untuk menampung data yang nilainya selalu tetap dan tidak pernah berubah. Jadi persamaan variabel system dan variabel konstan adalah sama sama untuk menampung data.
---> 